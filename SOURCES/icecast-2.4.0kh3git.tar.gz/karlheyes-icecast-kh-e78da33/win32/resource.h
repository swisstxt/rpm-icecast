//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Icecast2win.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ICECAST2WIN_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       132
#define IDB_BITMAP1                     134
#define IDB_BITMAP2                     135
#define IDI_R                           141
#define IDI_G                           142
#define IDI_ICON1                       142
#define IDD_SERVERSTATUS                144
#define IDD_SSTATUS                     145
#define IDD_CONFIGDIALOG                146
#define IDD_STATSDIALOG                 147
#define IDB_BITMAP3                     149
#define IDB_BITMAP4                     150
#define IDB_BITMAP5                     151
#define IDB_BITMAP6                     152
#define IDR_MENU2                       153
#define IDR_MENU3                       154
#define IDC_CURSOR1                     155
#define IDC_CURSOR2                     156
#define IDB_BITMAP7                     159
#define IDR_TRAY                        160
#define IDR_MENU4                       161
#define IDB_BITMAP8                     163
#define IDB_BITMAP9                     164
#define IDC_MAINTAB                     1000
#define IDC_ERROR_EDIT                  1003
#define IDC_ACCESS_EDIT                 1004
#define IDC_CONFIG_EDIT                 1006
#define IDC_SERVERSTATUS                1008
#define IDC_SOURCES_CONNECTED           1009
#define IDC_NUMBER_CLIENTS              1010
#define IDC_GROUP1                      1011
#define IDC_STATS_EDIT                  1012
#define IDC_CONFIG                      1020
#define IDC_STATSLIST                   1021
#define IDC_SOURCELIST                  1022
#define IDC_START                       1023
#define IDC_AUTOSTART                   1024
#define IDC_FILLER1                     1025
#define IDC_FILLER2                     1026
#define IDC_STATIC_SS                   1029
#define IDC_GLOBALSTAT_LIST             1030
#define IDC_STATIC_GS                   1031
#define IDC_STATIC_SLS                  1032
#define IDC_RUNNINGFOR                  1033
#define IDC_STATIC_RUN                  1034
#define IDC_STATICBLACK                 1035
#define IDC_HIDESYSTRAY                 1036
#define ID_FILE_STARTSERVER             32771
#define ID_FILE_EXIT                    32772
#define ID_FILE_STOPSERVER              32774
#define ID_FILE                         32775
#define ID_POPUP_ADDTOGLOBALSTATLIST    32776
#define ID__DELETEFROMGLOBALSTATS       32777
#define ID__MAKETHISSTATTHEWINDOWTITLE  32779
#define ID_BLANK_RESTORE                32780
#define ID_ABOUT_HELP                   32781
#define ID_FILE_EDITCONFIGURATION       32782
#define ID_ABOUT_CREDITS                32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        165
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
